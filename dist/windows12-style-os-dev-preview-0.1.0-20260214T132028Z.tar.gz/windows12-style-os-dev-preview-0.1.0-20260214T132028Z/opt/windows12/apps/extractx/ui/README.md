# ExtractX UI Preview

Open `index.html` in a browser to review the visual direction for the extraction app.

This preview mirrors the glass/translucent shell style and responsive layout targets.
